import boto3
import simplejson as json 
import os 
import uuid
from datetime import datetime
import logging
import requests
import random
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

s3 = boto3.client('s3')
bucket = os.environ.get('QUOTE_BUCKET')

dynamodb = boto3.resource('dynamodb')
table_name = os.environ.get('USERS_TABLE')
table = dynamodb.Table(table_name) 


obj = s3.get_object(Bucket=bucket, Key= "quotes.json")
file_content = obj['Body'].read().decode('utf-8')
quotes = json.loads(file_content)

sns_client = boto3.client('sns')
topic = os.environ.get('QUOTES_TOPIC')

logger = logging.getLogger('customer_details')   #logging helps print log messages
logger.setLevel(logging.INFO)


def get_quote(event, context):

    random_number = random.randint(0, len(quotes['quotes']))

    random_quote = quotes['quotes'][random_number]['quote']
    author_quote = quotes['quotes'][random_number]['author']

    return {
        'statusCode': 200,
        'headers': {'Content-type':'application/json'},
        'body': json.dumps({'quote': random_quote, 'author': author_quote })
    }

def getSubscribers(event, context):

    email_content = table.scan(AttributesToGet=['email'])

    mailer_list =[]

    number_of_emails = len(email_content['Items'])

    for n in range(0, number_of_emails) :

        single_email = email_content['Items'][n]['email']

        mailer_list.append(single_email)


    return {
            'statusCode': 200,
            'headers': {'Content-type':'application/json',
                        'Access-Control-Allow-Origin':'*'},
            'body': json.dumps(mailer_list)
        }


def save_user_details(event, context):

    now = datetime.now()

    data = json.loads(event['body'])


    if isinstance(data['email'], str) != True :

        logger.info('Validation Failed')

        return

    else :

        subscriber_details= {

                    'userid': str(uuid.uuid4()), #generates a random large id 
                    'email': data['email'],
                    'subscribed': True,        #fills the table with id and attributes for the primary key
                    'createdAt': str(now.strftime("%d/%m/%Y %H:%M:%S")),
                    'updatedAt': str(now.strftime("%d/%m/%Y %H:%M:%S")),
                }

        response = table.put_item(

            Item = subscriber_details

        )    


        return {
            'statusCode': 200,
            'headers': {'Content-type':'application/json',
                        'Access-Control-Allow-Origin':'*'},
            'body': json.dumps(subscriber_details)
        }
    

def staticMailer(event, context):

    data = json.loads(event['body'])

    subscribers_json = getSubscribers(event)

    subscribers = json.loads(subscribers_json['body'])
    
    url =  'https://5bgn5ayjal.execute-api.us-west-2.amazonaws.com/Stage/static-mailer'
    
    post_request = requests.post(url, {'email': data['email']})

    emailBody = buildEmailBody(event["requestContext"]["identity"], data)

    save_url =  'https://5bgn5ayjal.execute-api.us-west-2.amazonaws.com/Stage/subscribe'

    save_details = requests.post(save_url, json=data)

    publishToSNS(input_message= emailBody)

    content_json = json.loads(get_quote(event, context))

    random_quote = content_json['body']['quote']

    author = content_json['body']['author']

    content = createEmail(random_quote, author)

    sendGridEmail(subscribers= subscribers, content= content)

    return {

            'statusCode': 200,
            'headers': {'Access-Control-Allow-Credentials': False,
                        'Access-Control-Allow-Origin':'*'},
            'body': json.dumps({'message': 'Ok'}),
        }



def publishToSNS(input_message) :

    sns_client.publish(  #publish our message to SNS
            TopicArn=topic,
            Message= json.dumps({'default': json.dumps(input_message)}),   #turns the message into json format to publish to SNS
            MessageStructure= 'json',
    )


def buildEmailBody(id, form):

    return {

        'Message': form['message'],
        'Name': form['name'],
        'Email': form['email'],
        'Service_Information': id['sourceIp'],
    }
    
def sendGridEmail(subscribers, content):

    message = Mail(
    from_email='ShaivaMuthaiya@gmail.com',
    to_emails= subscribers,
    subject='Quotes to brighten up your day',
    html_content= content)

try:
    sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
    response = sg.send(message)
    print(response.status_code)
    print(response.body)
    print(response.headers)

except Exception as e:
    print(e.message)


def createEmail(random_quote, author):

    return  ('''<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
            <html lang="en">
        
            
            <body>
            <div class="container", style="min-height: 40vh;
            padding: 0 0.5rem;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;"> 
            <div class="card" style="margin-left: 20px;margin-right: 20px;">
                <div style="font-size: 14px;">
                <div class='card' style=" background: #f0c5c5;
                border-radius: 5px;
                padding: 1.75rem;
                font-size: 1.1rem;
                font-family: Menlo, Monaco, Lucida Console, Liberation Mono,
                    DejaVu Sans Mono, Bitstream Vera Sans Mono, Courier New, monospace;">
            
                <p>${random_quote}</p>
                <blockquote>by ${author}</blockquote>
            
            </div>
                <br>
                </div>
                
                
                <div class="footer-links" style="display: flex;justify-content: center;align-items: center;">
                    <a href="/" style="text-decoration: none;margin: 8px;color: #9CA3AF;">Unsubscribe?</a>
                    <a href="/" style="text-decoration: none;margin: 8px;color: #9CA3AF;">About Us</a>
                
                </div>
                </div>
            
                    </div>
                
            </body>
            </html>''')

